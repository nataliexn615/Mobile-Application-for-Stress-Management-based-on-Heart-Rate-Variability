//
//  ViewController.swift
//  SmartCameraLBTA
//
//  Created by Brian Voong on 7/12/17.
//  Copyright © 2017 Lets Build That App. All rights reserved.
//

import UIKit
import AVKit
import Vision
//var hrvArray = [hrvData]()

class EmotionDetectionViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
  
    private var timer = Timer()
    var count = 0
    static var emotionArray: Array<String> = []
    let identifierLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let captureSession = AVCaptureSession()
    override func viewDidLoad() {
       
        EmotionDetectionViewController.emotionArray.removeAll()
        super.viewDidLoad()
   
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        
        captureSession.sessionPreset = .photo
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.addInput(input)
        captureSession.startRunning()
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer)
        previewLayer.frame = view.frame
        
        let dataOutput = AVCaptureVideoDataOutput()
     
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
        
        setupIdentifierConfidenceLabel()

    }
    @objc func updateCounter() {
            //example functionality
            if count < 5 {
                count += 1
                print(count)
              //  print(count)
            } else{
                captureSession.stopRunning()
                let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)

                let vc: UIViewController = storyboard.instantiateViewController(withIdentifier: "EmotionResult")

                        self.present(vc, animated: true, completion: nil)
                print("stopped")
            }
            }
    
    fileprivate func setupIdentifierConfidenceLabel() {
       view.addSubview(identifierLabel)
        identifierLabel.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -32).isActive = true
        identifierLabel.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        identifierLabel.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        identifierLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    static var giveResult: String = ""
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        print("Camera was able to capture a frame:", Date())
        
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        

        guard let model = try? VNCoreMLModel(for: Test1().model) else { return }
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            
            guard let results = finishedReq.results as? [VNClassificationObservation] else { return }
            
            guard let firstObservation = results.first else { return }
            
            print(firstObservation.identifier, firstObservation.confidence)
            EmotionDetectionViewController.giveResult = firstObservation.identifier
            DispatchQueue.main.async {
                self.identifierLabel.text = "\(firstObservation.identifier)"
                EmotionDetectionViewController.emotionArray.append(firstObservation.identifier)
        
            }
            
        }
        
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }

}

