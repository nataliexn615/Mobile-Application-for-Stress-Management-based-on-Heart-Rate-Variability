#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)startMonitor:(id)sender;
@end

