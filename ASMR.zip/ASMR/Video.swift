//
//  Video.swift
//  AV Player
//
//  Created by Merlyn on 10/2/15.
//  Copyright © 2015 The App Lady. All rights reserved.
//

import UIKit

class Video: NSObject {
    var title: String!
    var url: String!
}
